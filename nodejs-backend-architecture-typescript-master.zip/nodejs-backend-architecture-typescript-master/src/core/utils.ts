export const enum Header {
  API_KEY = 'x-api-key',
  AUTHORIZATION = 'authorization',
}
