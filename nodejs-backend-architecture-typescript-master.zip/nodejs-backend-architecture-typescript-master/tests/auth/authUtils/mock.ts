export const ACCESS_TOKEN_KEY = 'abc';
export const REFRESH_TOKEN_KEY = 'xyz';
